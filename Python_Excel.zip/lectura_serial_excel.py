
import serial
import time
import pandas as pd

ser = serial.Serial('COM3', 9600)  # Cambia COM3 por el puerto correcto
time.sleep(2)

datos = []

try:
    while True:
        line = ser.readline().decode('utf-8').strip()
        print(line)
        parts = line.split(',')
        if len(parts) == 3:
            temp = float(parts[0].split(':')[1])
            hum = float(parts[1].split(':')[1])
            suelo = int(parts[2].split(':')[1])
            datos.append({'Temperatura': temp, 'Humedad': hum, 'HumedadSuelo': suelo})
            if len(datos) >= 10:
                break
finally:
    ser.close()

df = pd.DataFrame(datos)
df.to_excel("datos_sensores.xlsx", index=False)
print("Datos guardados en datos_sensores.xlsx")
