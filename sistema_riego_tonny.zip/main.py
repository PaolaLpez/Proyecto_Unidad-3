from machine import Pin, ADC
from time import sleep

sensor = ADC(Pin(34))  # Pin del sensor de humedad
sensor.atten(ADC.ATTN_11DB)  # Mayor rango de lectura
rele = Pin(26, Pin.OUT)

while True:
    humedad = sensor.read()
    print("Humedad:", humedad)
    if humedad < 2000:
        rele.value(0)  # Activa el riego
        print("Riego activado")
    else:
        rele.value(1)  # Desactiva el riego
        print("Riego desactivado")
    sleep(5)
